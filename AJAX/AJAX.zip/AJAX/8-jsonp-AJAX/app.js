// 1 数据
const data = {
    name: '你的名字'
};

//console.log(data.name);

// 2 函数的调用
My_name_is(data);